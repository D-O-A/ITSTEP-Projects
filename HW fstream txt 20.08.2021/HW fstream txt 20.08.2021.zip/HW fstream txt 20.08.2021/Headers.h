#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>
#include <vector>
using namespace std;

#include "OrderCollection.h"
#include "WriteToTxtFile.h"
