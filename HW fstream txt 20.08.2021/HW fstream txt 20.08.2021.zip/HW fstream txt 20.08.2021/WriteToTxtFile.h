#pragma once
#include "Headers.h"
class WriteToTxtFile
{
public:

	static void PrintToTxt(OrderCollection& order);
};

