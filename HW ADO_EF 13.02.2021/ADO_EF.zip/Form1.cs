﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ADO_EF
{
    public partial class Form1 : Form
    {
        private Model.FirmContext Firm;

        public Form1()
        {
            InitializeComponent();
            Firm = new Model.FirmContext();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // AddDepartments();
            // Firm.InstallManagers();
            MessageBox.Show(
                Firm.Managers.Count().ToString());            
        }

        private void buttonDepartments_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            foreach (var dep in
                Firm.Departments.OrderBy(d => d.Name))
            {
                listBox1.Items.Add(dep);
            }
        }
    }
}
